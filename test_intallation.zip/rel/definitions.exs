import Config

  config :set0,
    applications: ~w(app0 app1/app00),
    strip_beams: false

  config :set1,
    applications: ~w(child3/child4/child5 child6/child7)
