defmodule App00 do
  @moduledoc """
  Documentation for `App00`.
  """

  @doc """
  Hello world.

  ## Examples

      iex> App00.hello()
      :world

  """
  def hello do
    :world
  end
end
