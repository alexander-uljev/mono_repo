defmodule App00Test do
  use ExUnit.Case
  doctest App00

  test "greets the world" do
    assert App00.hello() == :world
  end
end
