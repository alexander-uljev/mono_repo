defmodule App0 do
  @moduledoc """
  Documentation for `App0`.
  """

  @doc """
  Hello world.

  ## Examples

      iex> App0.hello()
      :world

  """
  def hello do
    :world
  end
end
